-- Machine translated (2026-10-16); corrections welcome: https://github.com/cjber/skillup-forever/issues/new?template=translation.yml
local _, outer = ...
local ns = outer.SkillUp or {}
outer.SkillUp = ns
if GetLocale() ~= "zhTW" then
	return
end
local L = ns.L

L["%d %s"] = "%d %s"
L["%d crafts to %d, %s"] = "製造%d次至%d，%s"
L["%d crafts to %d, %s, at %s"] = "製造%d次至%d，%s，地點：%s"
L["%d more"] = "還有%d個"
L["%d to %d"] = "%d至%d"
L["%d, from %d to %d"] = "%d次，從%d到%d"
L["%dd ago"] = "%d天前"
L["%s %d"] = "%s %d"
L["%s (%d): bundled %d, classic-db %d"] = "%s（%d）：內建%d，classic-db %d"
L["%s (%d): bundled %s, the trainer wants %d"] = "%s（%d）：內建%s，訓練師要求%d"
L["%s (unlearned)"] = "%s（未學）"
L["%s is at %s."] = "%s位於%s。"
L["%s is in %s."] = "%s在%s。"
L["%s trainer"] = "%s訓練師"
L["%s until %d"] = "%s直到%d"
L["%s, %d"] = "%s，%d"
L["%s, %d/%d"] = "%s，%d/%d"
L["%s, %s, to %d"] = "%s，%s，至%d"
L["%s, source unknown"] = "%s，來源不明"
L["%s: %d moved, %d confirmed at a trainer, %d wrong."] =
	"%s：移動%d個，在訓練師處確認%d個，錯誤%d個。"
L["+%d more"] = "另有%d個"
L["/wp skipped lists the recipes you skipped, with their IDs."] = "/wp skipped 列出你跳過的配方及其ID。"
L["/wp unskip <recipe ID> shows one again, /wp unskip all every one."] =
	"/wp unskip <recipe ID> 恢復顯示一個，/wp unskip all 恢復全部。"
L["A Reagents tab on a merchant's window that lists the reagents your tracked routes still need from that merchant and their total cost. Buy them from the merchant's own window."] =
	"在商人視窗顯示材料分頁，列出你追蹤的路線仍需要向該商人購買的材料及其總費用。請在商人視窗中購買。"
L["A material your professions gather costs what selling it would bring instead of nothing: its auction price after the 5% cut, or its vendor sell price if that is more. Used for the route and the costs on recipe rows. Auction prices need Auctionator."] =
	"你的專業技能採集的材料按出售所得計價，而不是免費：扣除5%手續費後的拍賣價，或較高時按商人收購價。用於路線和配方列的成本。拍賣價需要Auctionator。"
L["Keeps the shared Forever tracker where you put it. The grip at its top no longer drags it."] =
	"將共用的 Forever 追蹤器保持在您放置的位置。頂部的拖曳握把不再移動它。"
L["Lock the tracker"] = "鎖定追蹤器"
L["Tracker background"] = "追蹤器背景"

L["A side tab on the Professions window listing the newest crafted item this character can equip in each slot, under the route tab."] =
	"專業技能視窗側邊的標籤頁（在路線標籤頁下方），列出此角色每個部位可裝備的最新製造物品。"
L["A side tab on the Professions window with a route to your target skill and its reagents. Tracked professions stay in the objective tracker either way."] =
	"專業技能視窗側邊的標籤頁，顯示到目標技能的路線及所需材料。無論如何，追蹤的專業技能都會保留在目標追蹤器中。"
L["AH"] = "拍賣場"
L["Add the start of each recipe's difficulty range. This is separate from the skill needed to learn it."] =
	"顯示每個配方難度區間的起點。這與學習它所需的技能不同。"
L["Addon"] = "插件"
L["Adventure Guide Forever can plan this quest chain."] = "Adventure Guide Forever可以規劃這條任務鏈。"
L["Also for this slot"] = "此部位的其他物品"
L["Annotate trainer recipes"] = "標註訓練師配方"
L["Another craft makes this recipe, not yours."] = "此配方由其他專業技能製造，而不是你的。"
L["Another crafter"] = "其他製造者"
L["At the %d cap: no trainer teaches the next rank."] = "已達上限%d：沒有訓練師教授下一等級。"
L["At the cursor"] = "滑鼠位置"
L["AtlasLoot is installed but not running: enable it in the AddOns list, or update it if out of date."] =
	"AtlasLoot已安裝但未執行：請在插件列表中啟用，或在過期時更新。"
L["Attach to quest tracker"] = "附著到任務追蹤器"
L["Auction house"] = "拍賣場"
L["Auction price if higher"] = "拍賣價（若較高）"
L["Auctionator hasn't seen these reagents yet: scan the auction house with it to price them."] =
	"Auctionator尚未見過這些材料：請用它掃描拍賣場以取得價格。"
L["Auctionator's scan when the auction house opens is off: turn it on in Auctionator, Basic Options."] =
	"Auctionator在開啟拍賣場時的掃描已關閉：請在Auctionator的「Basic Options」中開啟。"
L["Auctionator, %s"] = "Auctionator，%s"
L["Back"] = "背部"
L["Beside the Professions window"] = "專業技能視窗旁邊"
L["Buy %d %s"] = "購買%d個%s"
L["Buy %s"] = "購買%s" -- mt
L["Buy %s at %d"] = "在%2$d購買%1$s" -- mt
L["Buy all"] = "全部購買"
L["Buy and read %s at %d"] = "購買並閱讀%s（技能%d）"
L["Buy and read %s at %d (level %d)"] = "購買並閱讀%s（技能%d，等級%d）"
L["Buy reagents"] = "購買材料"
L["Buy reagents at the auction house"] = "在拍賣場購買材料"
L["Can learn it"] = "可以學習"
L["Cheapest skill-up"] = "最便宜的技能提升"
L["Chest"] = "胸部"
L["Click for a waypoint to %s."] = "點擊設定前往%s的導航點。"
L["Click for a waypoint."] = "點擊設定導航點。"
L["Click to craft %d."] = "點擊製造%d個。"
L["Click to open the recipe."] = "點擊開啟配方。"
L["Click to show a recipe again."] = "點擊恢復顯示一個配方。"
L["Close"] = "關閉"
L["Complete %s at %d"] = "完成%s（技能%d）"
L["Complete %s at %d (level %d)"] = "完成%s（技能%d，等級%d）"
L["Complete %s first: you're at your cap."] = "請先完成%s：你已達上限。"
L["Copy link"] = "複製連結"
L["Copy the address, then open it in your browser."] = "複製該網址，然後在瀏覽器中開啟。"
L["Cost"] = "成本"
L["Count what crafts sell for"] = "計入製造品的售價"
L["Craft %d %s"] = "製造%d個%s"
L["Craft %d of %d× %s"] = "製造%d/%d× %s"
L["Craft %d× %s"] = "製造%d× %s"
L["Craft %s"] = "製造%s"
L["Craft next"] = "製造下一個"
L["Crafted gear"] = "製造裝備"
L["Crafts"] = "製造次數"
L["Don't count it"] = "不計入"
L["Don't suggest this again"] = "不再推薦"
L["Drag to move"] = "拖曳以移動"
L["Dropped by"] = "掉落自"
L["Each"] = "單價"
L["Each click puts the next one in the search box; press Search."] =
	"每次點擊會把下一個填入搜尋框；然後點擊搜尋。"
L["Enable Shortest Path Forever for walked routes and boat times."] =
	"啟用Shortest Path Forever以取得步行路線和船隻時刻。"
L["Every recipe that uses it"] = "所有使用它的配方"
L["Fee"] = "費用"
L["Fee %s, requires %s (%d)"] = "費用%s，需要%s（%d）"
L["Feet"] = "腳"
L["Finger"] = "手指"
L["First used at"] = "首次使用於"
L["Forever addons"] = "Forever插件"
L["Forever tracker"] = "Forever追蹤器"
L["Gather %d %s"] = "採集%d個%s"
L["Gathering skill on nodes"] = "採集點的採集技能"
L["Hands"] = "手"
L["Have (bags and bank)"] = "已有（背包和銀行）"
L["Head"] = "頭部"
L["Herb and ore node tooltips show the skill they need and its colour at yours (English client only). Skinnable corpses show ? until the skinning rule is confirmed on Forever."] =
	"草藥和礦脈的滑鼠提示會顯示所需技能及其相對你技能的顏色（僅限英文用戶端）。可剝皮的屍體在Forever上的剝皮規則確認前顯示?。"
L["Install AtlasLoot to see the recipes vendors, quests and drops would add."] =
	"安裝AtlasLoot以查看商人、任務和掉落可提供的配方。"
L["Install Questie and AtlasLoot to see where recipes, vendors and trainers are."] =
	"安裝Questie和AtlasLoot以查看配方、商人和訓練師的位置。"
L["Install Questie to see vendors, quests and trainers, with waypoints to them."] =
	"安裝Questie以查看商人、任務和訓練師，並可設定導航點。"
L["Installed, turned off"] = "已安裝，已停用"
L["Its trainer should teach these at your skill now:"] = "以你現在的技能，訓練師應該能教你這些："
L["Kept in the Auctionator list '%s'."] = "已儲存在Auctionator列表「%s」中。"
L["Latest Auctionator prices."] = "最新的Auctionator價格。"
L["Latest Auctionator prices: rescan to update old prices."] =
	"最新的Auctionator價格：重新掃描以更新舊價格。"
L["Learn a crafting profession to plan a route."] = "學習一個製造專業技能來規劃路線。"
L["Legs"] = "腿部"
L["Level %d"] = "等級%d"
L["Level %d %s"] = "等級%d %s"
L["Levelling route"] = "升級路線"
L["Made at"] = "製造地點"
L["Main hand"] = "主手"
L["Missing reagents for this step."] = "此步驟缺少材料。"
L["Money on recipe rows"] = "配方列中的金額"
L["Nearest trainer"] = "最近的訓練師"
L["Nearest vendor"] = "最近的商人"
L["Neck"] = "頸部"
L["Need %d more %s"] = "還需要%d個%s"
L["Need a %s in your bags."] = "背包中需要%s。"
L["Needs %s %d"] = "需要%s %d"
L["Net per craft"] = "每次製造淨成本"
L["Next to the recipe"] = "配方旁邊"
L["No crafted gear for your level and class yet."] = "暫無適合你等級和職業的製造裝備。"
L["No crafted gear you can make yet. Tick the box above to see gear you cannot make."] =
	"暫無你能製造的裝備。勾選上方的選項以查看你不能製造的裝備。"
L["No skill data for this recipe yet."] = "此配方暫無技能資料。"
L["No trainer teaches this rank: a book does."] = "沒有訓練師教授此等級：需要書籍。"
L["No trainer teaches this rank: a quest does."] = "沒有訓練師教授此等級：需要任務。"
L["Not in this route: you chose Not this recipe."] = "不在此路線中：你選擇了「不要此配方」。"
L["Not installed"] = "未安裝"
L["Not this recipe"] = "不要此配方"
L["Nothing priced you know skills up past %d."] = "你已知且有價格的配方都無法將技能提升到%d以上。"
L["Nothing to buy for this route."] = "此路線無需購買任何物品。"
L["Nothing to craft on this route."] = "此路線無需製造任何物品。"
L["Nothing you know skills up past %d."] = "你已知的配方都無法將技能提升到%d以上。"
L["Off hand"] = "副手"
L["On"] = "開啟"
L["On %s"] = "在%s"
L["One line in chat the first time a new version loads."] = "新版本首次載入時在聊天框顯示一行。"
L["Open"] = "開啟"
L["Open %s to craft from here."] = "開啟%s以便在此製造。"
L["Open recipe"] = "開啟配方"
L["Orange, yellow, green and grey thresholds when hovering a recipe."] =
	"滑鼠停在配方上時顯示橙、黃、綠、灰的分界點。"
L["Per craft"] = "每次製作"
L["Per skill-up"] = "每點技能"
L["Per skill-up is the cost of one skill point. Per craft is what one craft costs or earns, shown on recipes that no longer give skill too."] =
	"每點技能是提升一點技能的成本。每次製作是一次製作的成本或收益，不再提升技能的配方也會顯示。"
L["Picks quests for your level and plans them into one journey."] =
	"挑選適合你等級的任務，並規劃成一段旅程。"
L["Plans the cheapest route to your next profession rank."] = "規劃升到下一個專業等級最省錢的路線。"
L["Plans the quickest way anywhere and guides you there, with live boat and zeppelin times."] =
	"規劃前往任何地點的最快路線並為你引路，附帶船隻與飛艇的即時時刻。"
L["Price"] = "價格"
L["Price %s, requires %s (%d)"] = "價格%s，需要%s（%d）"
L["Prices"] = "價格"
L["Profession reagents"] = "專業技能材料"
L["Profit per craft"] = "每次製造利潤"
L["Profit per skill-up"] = "每點技能利潤"
L["Quest"] = "任務"
L["Quest automation, rare alerts and merchant handling for the default UI."] =
	"為預設介面提供任務自動化、稀有怪提醒與商人處理。"
L["Quest giver"] = "任務給予者"
L["Quest, requires %s (%d)"] = "任務，需要%s（%d）"
L["Raises your skill cap to %d."] = "將你的技能上限提高到%d。"
L["Ranged"] = "遠程"
L["Read %s at %d"] = "閱讀%s（技能%d）"
L["Read %s at %d (level %d)"] = "閱讀%s（技能%d，等級%d）"
L["Read %s first: you're at your cap."] = "請先閱讀%s：你已達上限。"
L["Reagent cost divided by skill-up chance, on recipe rows and in the tooltip. Common vendor reagents are priced from the start and updated at merchants you visit, reagents you gather are free unless you value them under Prices, and auction prices need Auctionator."] =
	"材料成本除以技能提升機率，顯示在配方列和滑鼠提示中。常見商人材料一開始就有價格，並在你造訪商人時更新；你採集的材料免費，除非你在「價格」中為其定價；拍賣價需要Auctionator。"
L["Reagent tooltips"] = "材料滑鼠提示"
L["Reagents"] = "材料"
L["Reagents  (have / need)"] = "材料  （已有 / 需要）"
L["Reagents for"] = "材料用於"
L["Reagents in hand"] = "材料已備齊"
L["Reagents still needed"] = "仍需的材料"
L["Recipe rows"] = "配方列"
L["Recipe tooltip position"] = "配方提示位置"
L["Recipes from vendors, quests and drops that would carry it on:"] =
	"可以繼續提升的商人、任務和掉落配方："
L["Required skill, skill-up chance and cost on profession trainer recipes, and which one is best to train next for your route."] =
	"在專業技能訓練師的配方上顯示所需技能、技能提升機率和成本，並指出你的路線下一步最適合學習哪個。"
L["Requires"] = "需要"
L["Route"] = "路線"
L["Route and trainer"] = "路線和訓練師"
L["Route incomplete: %d recipes left out, their reagents not priced yet."] =
	"路線不完整：遺漏了%d個配方，其材料尚無價格。"
L["Route needs"] = "路線需要"
L["Route: %d/%d · %s to %d"] = "路線：%d/%d · %s至%d"
L["Scan the auction house with Auctionator, or visit a vendor, to price reagents."] =
	"用Auctionator掃描拍賣場或造訪商人來取得材料價格。"
L["Scroll"] = "配方"
L["Search"] = "搜尋"
L["Search reagents at the auction house"] = "在拍賣場搜尋材料"
L["Sells for"] = "售價"
L["Sells for x%g"] = "售價 x%g"
L["Set waypoint"] = "設定導航點"
L["Shift-click to link the scroll."] = "Shift-點擊以連結配方。"
L["Shift: used in %d of your recipes"] = "Shift：用於你的%d個配方"
L["Shoulder"] = "肩部"
L["Show a quiet line where one of my other Forever addons would help. Only for addons you don't have."] =
	"在我的其他Forever插件能幫上忙的地方顯示一行不顯眼的提示。僅限你尚未安裝的插件。"
L["Show again: %s"] = "恢復顯示：%s"
L["Show cost per skill-up"] = "顯示每點技能成本"
L["Show gear I cannot make yet"] = "顯示我還不能製造的裝備"
L["Show profession routes in the objective tracker. Hiding them keeps your tracked professions and targets."] =
	"在目標追蹤器中顯示專業技能路線。隱藏時會保留你追蹤的專業技能和目標。"
L["Show skill on recipe rows"] = "在配方列顯示技能"
L["Show skill range start on rows"] = "在列上顯示區間起點"
L["Show the merchant Reagents tab"] = "顯示商人材料分頁"
L["Show the crafted gear tab"] = "顯示製造裝備標籤頁"
L["Show the levelling route tab"] = "顯示升級路線標籤頁"
L["Show thresholds tooltip"] = "顯示分界點提示"
L["Show tracked professions"] = "顯示追蹤的專業技能"
L["Shows the Legacy challenges you can advance in each zone."] =
	"顯示每個地區中你可以推進的傳承挑戰。"
L["Skill  %d/%d     Target"] = "技能  %d/%d     目標"
L["Skill points a craft"] = "每次製造技能點"
L["Skill range start"] = "區間起點"
L["Skill range starts at %d"] = "區間起點為%d"
L["Skill-up chance"] = "技能提升機率"
L["Skill-up chance and cost per skill-up at the right of each recipe."] =
	"在每個配方右側顯示技能提升機率和每點技能成本。"
L["Skill-up chance: %d%%"] = "技能提升機率：%d%%"
L["SkillUp report"] = "SkillUp報告"
L["Skipped (%d)"] = "已跳過（%d）"
L["Skipped (%d):"] = "已跳過（%d）："
L["Sold by"] = "出售者"
L["Sort by"] = "分類方式為"
L["Sort recipes"] = "配方排序"
L["Sort recipes in one list, learned first, then unlearned. Default restores categories."] =
	"將配方排成一個列表，已知的在前，未學的在後。「預設值」恢復分類。"
L["Source"] = "來源"
L["Source unknown"] = "來源不明"
L["Stop tracking"] = "停止追蹤"
L["Subtract what the crafted item sells for from its cost. Auction prices need Auctionator, are after the 5% cut, and may not sell."] =
	"從成本中減去製造物品的售價。拍賣價需要Auctionator，已扣除5%手續費，且不一定能賣出。"
L["Suggest my other Forever addons"] = "推薦我的其他Forever插件"
L["Taught by %s trainers."] = "由%s訓練師教授。"
L["The Professions window no longer stutters while it is open."] = "專業技能視窗開啟時不再卡頓。" -- mt
L["The Forever addons are free, with nothing locked behind them. If they help, you can buy me a coffee."] =
	"Forever 插件全部免費，沒有任何付費才能使用的內容。如果它們對你有幫助，可以請我喝杯咖啡。" -- mt
L["The place this recipe is taught isn't known yet."] = "尚不清楚在哪裡學習此配方。"
L["The recipe list grows to the longest recipe name in the open profession, and the window with it, up to the room your screen has. Turn it off to keep the window's own width."] =
	"配方列表和視窗會加寬，以容納目前專業最長的配方名稱，最寬到螢幕空間為止。關閉後保持視窗原有寬度。"
L["The rest comes from a vendor or your gathering."] = "其餘來自商人或你的採集。"
L["The route asks for %d to reach %d in 9 runs of 10; a worse run needs more."] =
	"路線按%d個計算，十次中有九次能達到%d；運氣差時需要更多。"
L["The source of this recipe isn't known."] = "此配方的來源不明。"
L["The text is selected. Press Ctrl+C (Cmd+C on a Mac) to copy it, then paste it into your bug report."] =
	"文字已選取。按Ctrl+C（Mac上為Cmd+C）複製，然後貼到你的錯誤回報中。"
L["The tracker is locked. Turn off Lock the tracker to move it."] =
	"追蹤器已鎖定。關閉「鎖定追蹤器」即可移動它。"
L["These reagents have no vendor price. Auction prices need Auctionator."] =
	"這些材料沒有商人價格。拍賣價需要Auctionator。"
L["This addon"] = "本插件"
L["To buy"] = "待購買"
L["Tool"] = "工具"
L["Tooltips and sorting"] = "滑鼠提示和排序"
L["Total %s"] = "總計%s"
L["Track"] = "追蹤"
L["Tracked routes (Shift for all)"] = "追蹤的路線（Shift顯示全部）"
L["Train %s"] = "學習%s"
L["Train %s at %d"] = "學習%s（技能%d）"
L["Train %s at %d (level %d)"] = "學習%s（技能%d，等級%d）"
L["Train %s first."] = "請先學習%s。"
L["Train %s first: you're at your cap."] = "請先學習%s：你已達上限。"
L["Trinket"] = "飾品"
L["Turn this off to drag the shared Forever tracker anywhere on screen."] =
	"關閉此項後可將共用的Forever追蹤器拖曳到螢幕任意位置。"
L["Update Questie to see vendors, quests and trainers, with waypoints to them."] =
	"更新Questie以查看商人、任務和訓練師，並可設定導航點。"
L["Used in"] = "用於"
L["Value gathered materials at what they'd sell for"] = "按售價計算採集的材料"
L["Vendor"] = "商人"
L["Vendor reagents"] = "商人材料"
L["Vendor sell price"] = "商人收購價"
L["Visit a vendor to price reagents. Auction prices need Auctionator."] =
	"造訪商人以取得材料價格。拍賣價需要Auctionator。"
L["Waist"] = "腰部"
L["Waypoint to a trainer"] = "前往訓練師的導航點"
L["Waypoint to a vendor: %s"] = "前往商人的導航點：%s"
L["Waypoint to the quest giver: %s"] = "前往任務給予者的導航點：%s"
L["What hovering an item says about your professions: how much of it your tracked routes need (hold Shift for every recipe that uses it), every such recipe and its colour, or nothing."] =
	"滑鼠停在物品上時顯示的專業技能資訊：你追蹤的路線需要多少（按住Shift查看所有使用它的配方）、所有此類配方及其顏色，或不顯示。"
L["What's new after an update"] = "更新後的新內容"
L["Where the tooltip goes when you hover a recipe. Beside the window, it stays clear of the reagents."] =
	"滑鼠指向配方時提示顯示的位置。放在視窗旁邊就不會擋住材料。"
L["While the auction house is open, the Professions window offers a search for the selected recipe's reagents: as many as the crafts you choose still need after your bags and bank. Auctionator's shopping list carries the quantities; without it, each click puts the next reagent in the search box."] =
	"拍賣場開啟時，專業技能視窗可以搜尋所選配方的材料：數量為扣除背包和銀行後，你選擇的製造次數仍需要的數量。Auctionator的購物清單會帶上數量；沒有它時，每次點擊會把下一個材料填入搜尋框。"
L["Widen the recipe list to fit recipe names"] = "加寬配方列表以容納配方名稱"
L["With Shortest Path Forever, a click leads you there."] = "有Shortest Path Forever時，點擊即可帶你前往。"
L["With Shortest Path Forever, this picks the nearest by travel time and leads you there."] =
	"有Shortest Path Forever時，會按路程時間選擇最近的並帶你前往。"
L["World drop"] = "世界掉落"
L["Wrist"] = "手腕"
L["You have it, requires %s (%d)"] = "已擁有，需要%s（%d）"
L["You have this book: read it."] = "你有這本書：閱讀它。"
L["You know it"] = "已知"
L["You: %d"] = "你：%d"
L["Your bags allow %d of the route's %d."] = "你的背包可放下%d個（路線需要%d個）。"
L["Your bags and bank have enough."] = "你的背包和銀行中已足夠。"
L["can't identify the profession %s (%s); please report it."] =
	"無法識別專業技能%s（%s）；請回報此問題。"
L["couldn't add tracked reagents to the objective tracker; please report it."] =
	"無法將追蹤的材料加入目標追蹤器；請回報此問題。"
L["crafts"] = "次製造"
L["drop"] = "掉落"
L["every skipped recipe is back in the route."] = "所有跳過的配方都已回到路線中。"
L["files are missing: restart the game (not /reload) after updating."] =
	"檔案遺失：更新後請重新啟動遊戲（而不是/reload）。"
L["for %s"] = "用於%s"
L["gather"] = "採集"
L["green"] = "綠色"
L["grey"] = "灰色"
L["item %d"] = "物品%d"
L["level %d"] = "等級%d"
L["makes %d %s"] = "製造%d個%s"
L["no price"] = "無價格"
L["no skipped recipes: right-click a step on the route page and choose Not this recipe."] =
	"沒有跳過的配方：在路線頁面右鍵點擊一個步驟並選擇「不要此配方」。"
L["no trainer requirements to check."] = "沒有需要檢查的訓練師要求。"
L["none"] = "無"
L["nothing to search for here: what's missing comes from a vendor or your gathering."] =
	"這裡沒有可搜尋的：缺少的來自商人或你的採集。"
L["open a profession first."] = "請先開啟一個專業技能。"
L["open the auction house's Buy tab, then search again."] =
	"請開啟拍賣場的購買標籤頁，然後再次搜尋。"
L["orange"] = "橙色"
L["over 3 weeks ago"] = "超過3週前"
L["profession %d"] = "專業技能%d"
L["quest"] = "任務"
L["recipe %d"] = "配方%d"
L["route set to %s, %s."] = "已設定前往%s的路線，%s。"
L["searching for %s: you need %d more."] = "正在搜尋%s：你還需要%d個。"
L["sorting failed and has been turned off: %s"] = "排序失敗，已關閉：%s"
L["the %s book"] = "書籍%s"
L["the %s quest"] = "任務%s"
L["the objective tracker isn't available, so tracked reagents can't be shown."] =
	"目標追蹤器無法使用，因此無法顯示追蹤的材料。"
L["the reagent names are still loading; search again in a moment."] =
	"材料名稱仍在載入；請稍後再次搜尋。"
L["today"] = "今天"
L["tracked, but the objective tracker section isn't attached; please report it."] =
	"已追蹤，但目標追蹤器中的區塊未附著；請回報此問題。"
L["unknown age"] = "時間不明"
L["unknown location"] = "位置不明"
L["updated to %s. %s"] = "已更新到%s。%s"
L["vendor"] = "商人"
L["waypoint set to %s, %s."] = "已設定前往%s的導航點，%s。"
L["world drop"] = "世界掉落"
L["yellow"] = "黃色"
L["you gather it (%s)"] = "你自己採集（%s）"
L["you gather it (%s), valued at its AH price"] = "你自己採集（%s），按拍賣價計算"
L["you gather it (%s), valued at its vendor sell price"] = "你自己採集（%s），按商人收購價計算"
L["your bags and bank already hold the reagents for that many."] =
	"你的背包和銀行已有足夠這麼多次的材料。"
L["No step yet: learn or train a %s recipe that skills up."] =
	"暫無步驟：學習或訓練一個能提升技能點的%s配方。"
L["Show thresholds bar on the recipe"] = "在配方上顯示技能門檻條" -- mt
L["The orange, yellow, green and grey thresholds and where your skill sits, under the recipe in the Professions window. Turn it off if it covers the reagents."] =
	"橙色、黃色、綠色和灰色門檻以及你的技能位置，顯示在專業視窗的配方下方。如果遮住材料請關閉。" -- mt
L["%s (%s to %d)"] = "%s（%s 至 %d）" -- mt
L["Buying for %s"] = "為 %s 採購" -- mt
L["  %d items have no price yet"] = "  %d 件物品還沒有價格"
L["%d x %s - %s each"] = "%d x %s - 每個 %s"
L["%d x %s - price unknown"] = "%d x %s - 價格未知"
L["%s to %d"] = "%s至%d"
L[", "] = "，"
L[", price seen %d days ago"] = "，%d 天前的價格"
L["/wp export - show the trainer requirements this character has seen, to paste into a report"] =
	"/wp export - 顯示此角色見過的訓練師要求，以便貼到報告中"
L["/wp issue - report a bug or request a feature with a ready-made GitHub issue link"] =
	"/wp issue - 回報錯誤或請求功能，並附上現成的 GitHub issue 連結"
L["/wp report - show a report to copy into a bug report"] = "/wp report - 顯示報告，以便複製到錯誤回報中"
L[": "] = "："
L["A buy trip needs Shortest Path Forever."] = "購買行程需要 Shortest Path Forever。"
L["Bug"] = "錯誤"
L["Bug: "] = "錯誤："
L["Copy issue link"] = "複製 issue 連結"
L["Copy list"] = "複製清單"
L["Copy report"] = "複製報告"
L["Feature request"] = "功能請求"
L["Feature request: "] = "功能請求："
L["Gather"] = "採集"
L["Need %d, have %d, missing %d  %s  %s each  %s"] = "需要 %d，現有 %d，缺少 %d  %s  每個 %s  %s"
L["No tracked profession"] = "沒有追蹤的專業"
L["Nothing is missing from the shopping list."] = "購物清單裡沒有缺少的東西。"
L["Nothing to buy"] = "沒有要買的東西"
L["Plan buy trip"] = "規劃購買"
L["Report a bug or request a feature"] = "回報錯誤或請求功能"
L["Shopping list"] = "購物清單"
L["Shortest Path Forever cannot plan the full trip; setting a waypoint to the first vendor."] =
	"Shortest Path Forever 無法規劃整個行程；已設定前往第一個商人的導航點。"
L["Shortest Path Forever is needed to plan this trip."] = "規劃此行程需要 Shortest Path Forever。"
L["WildProfessions shopping list"] = "WildProfessions 購物清單"
L["The link is selected. Press Ctrl+C (Cmd+C on a Mac), then paste into a browser; GitHub opens a filled-in issue."] =
	"連結已選取。按Ctrl+C（Mac上為Cmd+C），然後貼到瀏覽器中；GitHub 會開啟填好的 issue。"
L["The text is selected. Press Ctrl+C (Cmd+C on a Mac) to copy it."] =
	"文字已選取。按Ctrl+C（Mac上為Cmd+C）複製。"
L["Title"] = "標題"
L["Total for priced items: "] = "有價格物品合計："
L["Unknown"] = "未知"
L["What happened, or what you would like"] = "發生了什麼，或你希望有什麼"
L["no trainer requirement seen yet: open a profession trainer, then try again."] =
	"尚未見到訓練師要求：開啟專業訓練師，然後再試一次。"
L["on %s"] = "在%s身上"
L["price unknown"] = "價格未知"
L["Unpin recipe"] = "取消釘選配方" -- mt
L["Pin for skill-ups"] = "釘選以提升技能" -- mt
L["Right-click to pin or skip this recipe."] = "右鍵點擊可釘選或略過此配方。" -- mt
L["Unpin: %s"] = "取消釘選：%s" -- mt
L["Pinned for skill-ups."] = "已釘選以提升技能。" -- mt
L["Skill range unknown."] = "技能範圍未知。" -- mt
L["Already grey: no skill-ups."] = "已經變灰：無法提升技能。" -- mt
L["Requires skill %d."] = "需要技能 %d。" -- mt
L["Learn this recipe first."] = "請先學習此配方。" -- mt
L["Reagents not priced yet."] = "材料尚無價格。" -- mt
L["Outside this route or a newer pin takes priority."] = "不在此路線內，或較新釘選的配方優先。" -- mt
L["Pinned: %s"] = "已釘選：%s" -- mt
L["The newest pin takes priority where skill ranges overlap."] =
	"技能範圍重疊時，最近釘選的配方優先。" -- mt
L["Pinned (%d)"] = "已釘選（%d）" -- mt
L["/wp share on|off - control sharing with guild and group"] = "/wp share on|off - 控制與公會和隊伍共享"
L["Share observed recipe totals with guild and group"] = "與公會和隊伍共享觀察到的配方總數"
L["(you)"] = "(你)"
L["All time"] = "全部時間"
L["Forever Leaderboards"] = "Forever Leaderboards"
L["Forever standing"] = "Forever 總排名"
L["Forever: %s overall"] = "Forever：總計 %s"
L["Forever: %s overall this week"] = "Forever：本週總計 %s"
L["No one has reported yet."] = "還沒有人回報。"
L["Others' values are player-reported."] = "其他玩家的數值由玩家自行回報。"
L["Overall"] = "總覽"
L["Player"] = "玩家"
L["Points for placing on each addon's board."] = "在每個插件的排行榜上取得名次的分數。"
L["Rank"] = "排名"
L["Recipes observed"] = "已觀察配方"
L["Share my progress"] = "共享我的進度"
L["This week"] = "本週"
L["Uses Forever addons"] = "使用 Forever 插件"
L["Your guild and group"] = "你的公會和隊伍"
L["boards"] = "排行榜"
L["1st"] = "第1名"
L["2nd"] = "第2名"
L["3rd"] = "第3名"
L["4th"] = "第4名"
L["5th"] = "第5名"
L["6th"] = "第6名"
L["7th"] = "第7名"
L["8th"] = "第8名"
L["board"] = "排行榜"
L["/wp leaderboard - open Forever Leaderboards on this addon's tab (also /wp stats)"] =
	"/wp leaderboard - 在此插件分頁開啟 Forever Leaderboards（也可用 /wp stats）"
L["total"] = "總計"
L["On by default. Turn off to stop sending and receiving totals and hide other players. Local observations stay."] =
	"預設開啟。關閉後停止收發總數並隱藏其他玩家。本機觀察紀錄會保留。"
L["crafted"] = "製作" -- mt
L["List unlearned recipes"] = "列出未學習的配方"
L["Adds the recipes of the open profession you have not learned under an Unlearned divider, greyed and marked with a trainer or recipe item and the skill it asks. They cannot be selected or crafted."] =
	"在「未學習」分隔線下列出目前專業中你尚未學習的配方，以灰色顯示，並標明訓練師或配方以及所需技能。它們無法被選取或製作。"
L["Not learned · %s"] = "未學習 · %s"
L["Trainer"] = "訓練師"
L["Recipe item"] = "配方"
L["listing unlearned recipes failed: %s"] = "列出未學習的配方失敗：%s"
L["Nothing on this route can be gathered, fished or looted by you, so the switch changes nothing for it."] =
	"這條路線沒有你可以採集、釣魚或從生物身上拾取的東西，所以此開關不會改變什麼。" -- mt
L["On, a reagent you could gather, fish or loot from creatures is priced at a vendor or the auction house. Off, getting it yourself costs nothing."] =
	"開啟時，你可以採集、釣魚或從生物身上拾取的素材按商人或拍賣場價格計算。關閉時，自己取得不花費任何費用。" -- mt
L["On, a reagent you could gather, fish or loot from creatures is priced at a vendor or the auction house. Off, getting it yourself costs what it would sell for."] =
	"開啟時，你可以採集、釣魚或從生物身上拾取的素材按商人或拍賣場價格計算。關閉時，自己取得需要按出售價值計算。" -- mt
L["Loot %d %s from creatures"] = "從生物身上拾取 %d 個%s" -- mt
L["you loot it from creatures"] = "你從生物身上拾取" -- mt
L["you loot it from creatures, valued at its AH price"] = "你從生物身上拾取，按拍賣場價格計算" -- mt
L["you loot it from creatures, valued at its vendor sell price"] =
	"你從生物身上拾取，按商人出售價格計算" -- mt
L["Shift-click crafts all %d."] = "按住Shift點擊製造全部%d個。" -- mt
L["The game's Craft button is not ready for this recipe."] = "遊戲內建的製造按鈕尚未對這份配方就緒。" -- mt
L["vendor, limited stock"] = "商人，庫存有限" -- mt
L["Sells %d at a time"] = "每次出售 %d 個" -- mt
L["This route is mostly %s: %d recipes are left out until their reagents are priced."] =
	"這條路線主要需要%s：在材料定價前有%d個配方被排除。" -- mt
L["Price self-supplied reagents at auction values"] = "Price self-supplied reagents at auction values" -- mt
L["A reagent you gather, loot or already own costs what selling it would bring - its auction price after the 5% cut, or its vendor sell price if that is more - instead of counting as free. With no market price it stays unpriced rather than free. Auction prices need Auctionator."] =
	"A reagent you gather, loot or already own costs what selling it would bring - its auction price after the 5% cut, or its vendor sell price if that is more - instead of counting as free. With no market price it stays unpriced rather than free. Auction prices need Auctionator." -- mt

-- Shared debug log (Forever Core's Core/Log.lua).
L["Debug log is off."] = "偵錯記錄已關閉。"
L["Debug log is on for this session."] = "本次工作階段已開啟偵錯記錄。"
L["Debug log is on and pinned for this character."] = "此角色的偵錯記錄已開啟並釘選。"
L["Debug log is already on and pinned for this character."] = "此角色的偵錯記錄已經開啟並釘選。"
L["Debug log is off for this session; it is still pinned."] =
	"本次工作階段已關閉偵錯記錄，但仍保持釘選。"
L["Debug log is off and unpinned."] = "偵錯記錄已關閉並取消釘選。"
L["No addon has attached its log yet."] = "還沒有插件附加記錄。"
L["%s (last %d):"] = "%s（最近 %d 筆）："
L["%s: no lines yet."] = "%s：還沒有記錄行。"
L["Usage: /forever debug, /forever debug pin, /forever debug off, /forever debug show"] =
	"用法：/forever debug、/forever debug pin、/forever debug off、/forever debug show"
L["This menu needs mouse and keyboard."] = "此選單需要滑鼠和鍵盤。"
