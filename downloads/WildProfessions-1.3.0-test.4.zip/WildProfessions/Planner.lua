local _, WP = ...
WP = _G.WildProfessions or WP

WP.Planner = {}

local function normalizeName(value)
    return type(value) == "string" and value:lower():gsub("[^%a]", "") or ""
end

local function getEngineProfession(name)
    local public = _G.WildProfessionsPlannerAPI
    local api = type(public) == "table" and public.API
    if type(api) ~= "table" or type(api.Professions) ~= "function" then return nil end
    local ok, entries = pcall(api.Professions)
    if not ok or type(entries) ~= "table" then return nil end
    local wanted = normalizeName(name)
    for _, entry in ipairs(entries) do
        if normalizeName(entry.name) == wanted then return entry end
    end
end

local function itemName(itemID)
    if C_Item and type(C_Item.GetItemNameByID) == "function" then
        local ok, name = pcall(C_Item.GetItemNameByID, itemID)
        if ok and type(name) == "string" then return name end
    end
    if type(GetItemInfo) == "function" then
        local ok, name = pcall(GetItemInfo, itemID)
        if ok and type(name) == "string" then return name end
    end
    return "Item " .. tostring(itemID)
end

function WP.Planner.GetStatus(profession)
    if not profession then
        return { status = "unavailable", text = "Learn a profession to begin tracking." }
    end
    local state = WP:GetGuideState(profession)
    local engine = getEngineProfession(profession.name)
    if not state then
        return { status = "route-needed", text = "No bundled route is available for this profession yet." }
    end
    if state.status == "route-needed" then
        if engine then
            return {
                status = "active", text = "Follow the crafting plan and collect the listed reagents.",
                profession = profession.name, title = engine.title or (profession.name .. " plan"),
                skill = profession.skill or 0, maxSkill = profession.maxSkill or 300,
                engineSteps = engine.steps or {}, engineReagents = engine.reagents or {},
                engineRecipes = engine.recipes or {}, engine = engine,
            }
        end
        return {
            status = state.status,
            text = state.text,
            profession = profession.name,
        }
    end
    local result = {
        status = state.status,
        text = state.instructions or "",
        title = state.title,
        zone = state.zone,
        target = state.target,
        skill = state.skill,
        maxSkill = state.maxSkill,
        herbs = state.herbs,
        routeNote = state.routeNote,
        sourceStatus = state.sourceStatus,
        route = state.route,
        focus = state.focus,
        combinedProgress = state.combinedProgress,
        engineSteps = engine and engine.steps or {},
        engineReagents = engine and engine.reagents or {},
        engineRecipes = engine and engine.recipes or {},
        engine = engine,
    }
    return result
end

function WP.Planner.FormatEngineSteps(status, limit)
    local lines = {}
    local steps = status and status.engineSteps or {}
    if #steps > 0 then
        lines[#lines + 1] = "|cff67d5a3NEXT CRAFTING STEPS|r"
        for index = 1, math.min(#steps, limit or 3) do
            local step = steps[index]
            local text = step.text or step.kind or "Plan step"
            if step.detail and step.detail ~= "" then text = text .. " — " .. step.detail end
            lines[#lines + 1] = "- " .. text
        end
    end
    return table.concat(lines, "\n")
end

function WP.Planner.FormatEngineReagents(status, limit)
    local lines = {}
    local reagents = status and status.engineReagents or {}
    if #reagents > 0 then
        lines[#lines + 1] = "|cff67d5a3REAGENTS FOR THE PLAN|r"
        local shown = 0
        for _, reagent in ipairs(reagents) do
            if shown >= (limit or 5) then break end
            shown = shown + 1
            local have = tonumber(reagent.have) or 0
            local need = tonumber(reagent.need) or 0
            lines[#lines + 1] = string.format("%d/%d %s", math.min(have, need), need, itemName(reagent.itemID))
        end
        if #reagents > shown then lines[#lines + 1] = string.format("and %d more materials", #reagents - shown) end
    end
    return table.concat(lines, "\n")
end

function WP.Planner.SetStrategy(strategy)
    local allowed = { fastest = true, cheapest = true, owned = true }
    if not allowed[strategy] then return false end
    WP:EnsureDatabase()
    WP.db.settings.strategy = strategy
    WP:UpdateDashboard()
    WP:UpdateTracker()
    return true
end

